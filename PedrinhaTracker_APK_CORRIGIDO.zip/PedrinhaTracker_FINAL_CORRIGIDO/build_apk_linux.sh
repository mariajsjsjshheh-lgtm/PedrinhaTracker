#!/usr/bin/env bash
set -e
if ! command -v java >/dev/null; then echo 'JDK nao encontrado.'; exit 1; fi
if [[ -z "${ANDROID_HOME:-}" && -z "${ANDROID_SDK_ROOT:-}" ]]; then echo 'Android SDK nao detectado. Abra o projeto no Android Studio e instale o SDK 36.'; exit 1; fi
if [[ -x ./gradlew ]]; then ./gradlew :app:assembleDebug --no-daemon; else echo 'Abra no Android Studio e use Build > Build APK(s).'; fi
