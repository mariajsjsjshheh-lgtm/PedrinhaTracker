# 🔥 Pedrinha Tracker — projeto Android

Este é o projeto Android do Pedrinha Tracker, preparado para virar um APK instalável.

## O que já está dentro
- câmera traseira do celular;
- permissão real de câmera;
- tela em retrato;
- WebView local seguro para a câmera;
- calibração dos Copos 1, 2 e 3;
- seleção da pedrinha;
- rastreamento por trajetória/template;
- marcação visual da pedrinha selecionada;
- lógica embarcada localmente, sem depender de site depois de instalado.

## IMPORTANTE
O arquivo que você recebeu é o **projeto Android**, não um APK pronto. O ambiente desta conversa não possui Android SDK/build-tools, então não é possível produzir honestamente um `.apk` binário aqui.

### Caminho mais simples
1. Instale o Android Studio no computador.
2. Extraia esta pasta.
3. No Android Studio, escolha **File > New > Import Project** e selecione a pasta `PedrinhaTrackerAPK`.
4. Aguarde o Gradle sincronizar e instalar os componentes solicitados.
5. Use **Build > Build APK(s)**.
6. O APK aparecerá em `app/build/outputs/apk/debug/app-debug.apk`.

A documentação oficial do Android confirma que projetos existentes podem ser importados no Android Studio e que o APK pode ser gerado pelo menu de Build.

## Requisitos
- Android Studio atual;
- JDK 17;
- Android SDK 36;
- conexão com a internet apenas durante a configuração/primeiro build para baixar ferramentas/dependências.

## Observação de segurança
Não instale APKs de origem desconhecida. Quando tivermos o APK gerado, confira que ele veio deste projeto antes de instalar.
