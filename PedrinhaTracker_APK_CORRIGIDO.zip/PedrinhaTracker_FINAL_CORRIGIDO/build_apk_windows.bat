@echo off
setlocal
where java >nul 2>nul || (echo Java/JDK 17 nao encontrado. & pause & exit /b 1)
if "%ANDROID_HOME%"=="" if "%ANDROID_SDK_ROOT%"=="" echo Android SDK nao detectado. Abra o projeto no Android Studio para instalar o SDK 36. & pause & exit /b 1
if exist gradlew.bat (
  call gradlew.bat :app:assembleDebug --no-daemon
) else (
  echo Este pacote nao inclui o Gradle Wrapper. Abra no Android Studio e use Build ^> Build APK(s).
)
if exist app\build\outputs\apk\debug\app-debug.apk (
  echo.
  echo APK criado em: %CD%\app\build\outputs\apk\debug\app-debug.apk
) else echo APK ainda nao foi gerado.
pause
