
const video=document.getElementById('video'), canvas=document.getElementById('overlay'), ctx=canvas.getContext('2d');
const statusEl=document.getElementById('status'), hint=document.getElementById('hint');
let stream=null, mode='idle', tracks=[], ball=null, running=true, raf=0, lastT=0, work=null;

function setStatus(s){statusEl.textContent=s}
async function startCamera(){
  try{
    stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:'environment'},width:{ideal:1280},height:{ideal:720}},audio:false});
    video.srcObject=stream; await video.play(); resize(); setStatus('Câmera ligada'); loop();
  }catch(e){setStatus('Permita o acesso à câmera'); alert('O navegador precisa de acesso à câmera. Use HTTPS ou o app instalado.')}
}
function resize(){ if(video.videoWidth){canvas.width=video.videoWidth;canvas.height=video.videoHeight;}}
video.addEventListener('loadedmetadata',resize);
window.addEventListener('resize',resize);

function canvasPoint(ev){
 const r=canvas.getBoundingClientRect();
 return {x:(ev.clientX-r.left)*canvas.width/r.width,y:(ev.clientY-r.top)*canvas.height/r.height};
}
canvas.addEventListener('click',ev=>{
 if(mode==='cups'){
   const p=canvasPoint(ev);
   tracks.push({id:tracks.length+1,x:p.x,y:p.y,vx:0,vy:0,template:null,age:0});
   if(tracks.length===3){mode='idle'; captureTemplates(); setStatus('3 copos fixados'); hint.innerHTML='<b>Agora:</b> toque em “Marcar pedrinha” e selecione somente a pedrinha que deseja acompanhar.';}
   else setStatus(`Toque no Copo ${tracks.length+1}`);
 } else if(mode==='ball'){
   const p=canvasPoint(ev); ball={x:p.x,y:p.y,vx:0,vy:0,selected:true,visible:true,template:capturePatch(p.x,p.y,18,18)}; mode='idle'; setStatus('Pedrinha selecionada'); 
 }
});
document.getElementById('start').onclick=startCamera;
document.getElementById('calibrate').onclick=()=>{
 if(!stream)return setStatus('Abra a câmera primeiro');
 tracks=[];mode='cups';setStatus('Toque no Copo 1');
};
document.getElementById('ball').onclick=()=>{
 if(!stream)return setStatus('Abra a câmera primeiro');
 if(tracks.length!==3)return setStatus('Calibre os 3 copos primeiro');
 mode='ball';setStatus('Toque na pedrinha que quer seguir');
};
document.getElementById('pause').onclick=()=>{running=!running;document.getElementById('pause').textContent=running?'Pausar':'Continuar'; if(running)loop()};

function grayAt(x,y){
 const ix=Math.max(0,Math.min(canvas.width-1,x|0)), iy=Math.max(0,Math.min(canvas.height-1,y|0));
 return work[iy*canvas.width+ix];
}
function makeGray(){
 const w=canvas.width,h=canvas.height;
 const c=document.createElement('canvas'); c.width=w;c.height=h;
 const c2=c.getContext('2d',{willReadFrequently:true});c2.drawImage(video,0,0,w,h);
 const d=c2.getImageData(0,0,w,h).data, g=new Uint8Array(w*h);
 for(let i=0,j=0;i<d.length;i+=4,j++)g[j]=(d[i]*0.299+d[i+1]*0.587+d[i+2]*0.114)|0;
 return g;
}
function capturePatch(cx,cy,hw,hh){
 if(!work)return null;
 const w=canvas.width,h=canvas.height, x0=Math.round(cx-hw),y0=Math.round(cy-hh),pw=hw*2+1,ph=hh*2+1;
 const a=new Uint8Array(pw*ph); let k=0;
 for(let y=0;y<ph;y++)for(let x=0;x<pw;x++){let xx=Math.max(0,Math.min(w-1,x0+x)),yy=Math.max(0,Math.min(h-1,y0+y));a[k++]=work[yy*w+xx];}
 return {a,w:pw,h:ph,hw,hh};
}
function scorePatch(t,cx,cy){
 if(!t)return -1; const w=canvas.width,h=canvas.height;
 const x0=Math.round(cx-t.hw),y0=Math.round(cy-t.hh);
 if(x0<0||y0<0||x0+t.w>=w||y0+t.h>=h)return -1;
 let s1=0,s2=0,n=t.a.length,k=0;
 for(let y=0;y<t.h;y++)for(let x=0;x<t.w;x++){const v=work[(y0+y)*w+x0+x];s1+=v;s2+=v*v;k++}
 const m1=s1/n; let den2=0,num=0; k=0;
 let mt=0; for(const v of t.a)mt+=v; mt/=n;
 for(let y=0;y<t.h;y++)for(let x=0;x<t.w;x++){const a=t.a[k++]-mt,b=work[(y0+y)*w+x0+x]-m1;num+=a*b;den2+=b*b;}
 let den1=0;for(const v of t.a){const a=v-mt;den1+=a*a}
 return den1&&den2?num/Math.sqrt(den1*den2):-1;
}
function bestAround(t,cx,cy,rx=70,ry=70,step=5){
 let best={x:cx,y:cy,s:-1};
 for(let y=cy-ry;y<=cy+ry;y+=step)for(let x=cx-rx;x<=cx+rx;x+=step){
   const s=scorePatch(t,x,y);if(s>best.s)best={x,y,s};
 }
 return best;
}
function captureTemplates(){
 // Crown-centered templates; fixed dimensions make the box stable.
 for(const tr of tracks) tr.template=capturePatch(tr.x,tr.y,45,38);
}
function updateTracks(dt){
 for(const tr of tracks){
   const px=tr.x+tr.vx*dt,py=tr.y+tr.vy*dt;
   const b=bestAround(tr.template,px,py,85,65,5);
   if(b.s>0.28){
     const nx=b.x,ny=b.y; tr.vx=0.72*tr.vx+0.28*((nx-tr.x)/Math.max(dt,.016)); tr.vy=0.72*tr.vy+0.28*((ny-tr.y)/Math.max(dt,.016)); tr.x=nx;tr.y=ny;tr.age++;
   }else{tr.x=px;tr.y=py;tr.age++;}
   tr.vx=Math.max(-900,Math.min(900,tr.vx));tr.vy=Math.max(-900,Math.min(900,tr.vy));
 }
}
function redBallCandidate(){
 if(!ball)return null; const w=canvas.width,h=canvas.height, r=85;
 let best=null;
 for(let y=Math.max(0,ball.y-r);y<Math.min(h,ball.y+r);y+=4)for(let x=Math.max(0,ball.x-r);x<Math.min(w,ball.x+r);x+=4){
   const idx=(y|0)*w+(x|0),g=work[idx];
   // Work from RGB is unavailable here; use the original frame pixel sampling via a tiny canvas.
 }
 return best;
}
let rgbCtx=null,rgbCanvas=null;
function findRed(){
 if(!ball)return;
 if(!rgbCanvas){rgbCanvas=document.createElement('canvas');rgbCtx=rgbCanvas.getContext('2d',{willReadFrequently:true});}
 rgbCanvas.width=canvas.width;rgbCanvas.height=canvas.height;rgbCtx.drawImage(video,0,0,canvas.width,canvas.height);
 const d=rgbCtx.getImageData(0,0,canvas.width,canvas.height).data,w=canvas.width,h=canvas.height,r=95;
 let best=null,bestScore=0;
 const minX=Math.max(0,ball.x-r),maxX=Math.min(w,ball.x+r),minY=Math.max(0,ball.y-r),maxY=Math.min(h,ball.y+r);
 for(let y=minY;y<maxY;y+=4)for(let x=minX;x<maxX;x+=4){
   const i=((y|0)*w+(x|0))*4,R=d[i],G=d[i+1],B=d[i+2];
   const sc=(R>130&&R>G*1.45&&R>B*1.35)?R-G*.7-B*.3:0;
   if(sc>bestScore){bestScore=sc;best={x,y};}
 }
 if(best){
   const dt=Math.max(.016,(performance.now()-lastT)/1000);
   const vx=(best.x-ball.x)/dt,vy=(best.y-ball.y)/dt;
   ball.vx=.65*ball.vx+.35*vx;ball.vy=.65*ball.vy+.35*vy;ball.x=best.x;ball.y=best.y;ball.visible=true;
 }else{
   const dt=Math.max(.016,(performance.now()-lastT)/1000);ball.x+=ball.vx*dt;ball.y+=ball.vy*dt;ball.visible=false;
 }
}
function draw(){
 ctx.clearRect(0,0,canvas.width,canvas.height);
 for(const tr of tracks){
   const bw=180,bh=320,x=tr.x-bw/2,y=tr.y+15-bh/2;
   ctx.lineWidth=5;ctx.strokeStyle='#fff';ctx.strokeRect(x,y,bw,bh);
   ctx.font='bold 34px system-ui';ctx.lineWidth=7;ctx.strokeStyle='#000';ctx.strokeText(String(tr.id),x+8,y+40);ctx.fillStyle='#fff';ctx.fillText(String(tr.id),x+8,y+40);
 }
 if(ball&&ball.visible){
   ctx.beginPath();ctx.arc(ball.x,ball.y,25,0,Math.PI*2);ctx.lineWidth=6;ctx.strokeStyle='#fff';ctx.stroke();
   ctx.font='bold 24px system-ui';ctx.fillStyle='#fff';ctx.fillText('PEDRINHA',ball.x+32,ball.y+8);
 }
}
function loop(t=performance.now()){
 if(!running||!video.videoWidth){raf=requestAnimationFrame(loop);return}
 resize(); work=makeGray(); const dt=Math.max(.016,(t-lastT||16)/1000);lastT=t;
 if(mode==='idle'&&tracks.length===3)updateTracks(dt);
 if(ball) findRed();
 draw(); raf=requestAnimationFrame(loop);
}
